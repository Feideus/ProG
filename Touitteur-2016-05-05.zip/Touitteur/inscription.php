<?php
		 /**
		 *
		 */
		 class inscription 
		 {
		 	var $pseudo;
		 	var $passe;
		 	var $passe2;
		 	var $email;

			function testchamps(){
				if(!empty(this_$pseudo)){// D'abord,je teste si le champs login est non vide.  
					if(!empty(this_$passe)&&!empty(this_$passe2)){// Ensuite, je teste si le champs mdp est non vide.
						if(this$passe === this$passe2){	
							if (filter_var(this$email, FILTER_VALIDATE_EMAIL)) {
									return true;
							}
						}	
					}
				}
				return false;
			}
			
			function ajout()
			{			
								$bdd = new PDO('mysql:host=localhost;dbname=BDE11200183', 'E11200183', '2405067885Y');		
								// Je me connecte à la base de données .		
								// Je vais crypter le mot de passe.
								$passecoder = md5(this_$passe);	
								$bdd->query("INSERT INTO Touitos VALUES('','this_$pseudo','this_$email','$passecoder','','')");
								
			}

			function TestTouitos ()
			{
				var $login;
				$bdd = new PDO('mysql:host=localhost;dbname=BDE11200183', 'E11200183', '2405067885Y');		
				// Je me connecte à la base de données .
				$Touitos = $bdd ->prepare("SELECT pseudonyme, email from Touitos");

				$Touitos->execute();

				$Touitos->setFetchMode(PDO::FETCH_OBJ);

				while($user = $Touitos->fetch()){
					if (strcmp($user->pseudonyme, $login))
					{
						if(strcmp($user->email,$email))
						{
							return 2;
						}
							else
							{
								return 3;
							}
						}
					}
					return 1;
			}
				$this_passe = htmlentities($_POST['mdp']);
				$this_passe2 = htmlentities($_POST['mdp2']);
				$this_pseudo = htmlentities($_POST['pseudo']);
				$this_email = htmlentities($_POST['email']);
				if(testchamps()){
					switch (TestTouitos ($pseudo, $email)){
						case 1 :
							ajout($pseudo,$email,$passe);
							echo '<p>Compte crée!<br/> Voivi le lien vers la page d\'index<br/> <a href="connexion.html">Se connecter</a></p>';
							break;
						case 2 :
							header('Location: http://marseille/~11200183/Touitteur/inscription.html'); 
							exit();
							echo "pseudo deja utilisé"; 
							break;
						case 3 :
							header('Location: http://marseille/~11200183/Touitteur/inscription.html'); 
							exit();
							echo "email deja utilisé"; 
							break;
					}
				}
					
	?>