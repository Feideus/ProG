<!doctype html>
<html>

	<head> 
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<meta name="LANG" content="fr"/>
		<link rel="stylesheet" href="abonne.css" />
		<meta name="description" content=" Liste des abonnés"/>
		<title>Liste abonnés</title>
	</head>
	<body>
		<a href="connexion.html"> <header> <h1>TOUITTEUR</h1></header></a>
		<div id="titre_de_la_page">
				<h2>Abonnés de :</h2>
		</div>
		<nav>
				<fieldset>
					<legend>Navigation</legend>
					<ul>				    
						<li>
							 <a href="parametre.html"><p>Paramètres</p></a>
				 		</li>
				 		<li>
							<a href="listeabonné.html"><p> Liste des abonnés </p></a>
						</li>
						<li>
							<a href="chat.html"><p> Messages Privés</p></a>				
					</ul>
				</fieldset>
		</nav>
		<div id="thewall">
		<?php
			try
			{
			// On se connecte à MySQL
				$bdd = new PDO('mysql:host=localhost;dbname=BDE11200183;charset=utf8', 'root', '');
			}
			catch(Exception $e)
			{
				// En cas d'erreur, on affiche un message et on arrête tout
       			 die('Erreur : '.$e->getMessage());
			}

			// Si tout va bien, on peut continuer

			// On récupère tout le contenu de la table jeux_video
			$reponse = $bdd->query('SELECT nom_abonné FROM listeabonné WHERE nom_abonneur=$_SESSION['pseudo'] ');

			// On affiche chaque entrée une à une
			while ($donnees = $reponse->fetch())
			{
		?>
    		<p>
    			 <?php echo $donnees['nom_abonné']; ?> : <a href=localhost/ProgWeb/$donnees['nom_abonné']>
   			</p>
		<?php
			}

			$reponse->closeCursor(); // Termine le traitement de la requête

		?>


		</div>
		<footer>
			<p>@Touitteur Erwan & Gaëtan Tout droits réservés ©</p>
		</footer>
	</body>
</html>